﻿namespace FileManagement.Models
{
    public class File
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int FileGroupId { get; set; }
        public FileGroup FileGroup { get; set; }
    }
}
