﻿using FileManagement.DataAccessLayer;
using FileManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Security.Claims;

namespace FileManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class FileManagementController : ControllerBase
    {
        private readonly FileManagementDbContext _context;

        public FileManagementController(FileManagementDbContext context)
        {
            _context = context;
        }

        [HttpGet("file-groups")]
        [Authorize]
        public IActionResult GetFileGroups()
        {
            var role = User.FindFirst(ClaimTypes.Role).Value;
            var fileGroups = _context.FileGroups.ToList();

            switch (role)
            {
                case "Administrator":
                    return Ok(fileGroups);
                case "Salesperson":
                    return Ok(fileGroups.Where(fg => fg.Name != "Pictures"));
                case "WebDesigner":
                    return Ok(fileGroups.Where(fg => fg.Name == "Pictures" || fg.Name == "Manuals"));
                default:
                    return Forbid();
            }
        }

        [HttpGet("files")]
        [Authorize]
        public IActionResult GetFiles()
        {
            var role = User.FindFirst(ClaimTypes.Role).Value;
            var files = _context.Files.Include(f => f.FileGroup).ToList();

            switch (role)
            {
                case "Administrator":
                    return Ok(files);
                case "Salesperson":
                    return Ok(files.Where(f => f.FileGroup.Name != "Pictures"));
                case "WebDesigner":
                    return Ok(files.Where(f => f.FileGroup.Name == "Pictures" || f.FileGroup.Name == "Manuals"));
                default:
                    return Forbid();
            }
        }

        [HttpGet("users")]
        [Authorize(Roles = "Administrator")]
        public IActionResult GetUsers()
        {
            var users = _context.Users.ToList();
            return Ok(users);
        }

        [HttpGet("users/{username}")]
        [Authorize(Roles = "Administrator")]
        public IActionResult GetUserByUsername(string username)
        {
            var user = _context.Users.SingleOrDefault(u => u.Username == username);
            if (user == null)
                return NotFound();

            return Ok(user);
        }

        [HttpPost("users")]
        [Authorize(Roles = "Administrator")]
        public IActionResult AddUser([FromBody] User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetUserByUsername), new { username = user.Username }, user);
        }
    }
}

