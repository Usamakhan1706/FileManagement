﻿using FileManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace FileManagement.DataAccessLayer
{
    public class FileManagementDbContext : DbContext
    {
        public FileManagementDbContext(DbContextOptions<FileManagementDbContext> options) : base(options)
        {

        }
        public DbSet<User> Users { get; set; }
        public DbSet<Models.File> Files { get; set; }
        public DbSet<FileGroup> FileGroups { get; set; }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlite("Data Source=filemanagement.db");

        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Seed data
            modelBuilder.Entity<FileGroup>().HasData(
                new FileGroup { Id = 1, Name = "Pictures" },
                new FileGroup { Id = 2, Name = "Manuals" },
                new FileGroup { Id = 3, Name = "Drawings" },
                new FileGroup { Id = 4, Name = "Reports" }
            );

            modelBuilder.Entity<User>().HasData(
                new User { Id = 1, Username = "admin", Password = "admin", Role = "Administrator" },
                new User { Id = 2, Username = "sales", Password = "sales", Role = "Salesperson" },
                new User { Id = 3, Username = "designer", Password = "designer", Role = "WebDesigner" }
            );
        }
    }
}
