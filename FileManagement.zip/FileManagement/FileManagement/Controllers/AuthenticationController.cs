﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using FileManagement.DataAccessLayer;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using FileManagement.Models;
using Microsoft.AspNetCore.Authorization;
using System.Reflection.Metadata.Ecma335;
using Microsoft.EntityFrameworkCore;

namespace FileManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly FileManagementDbContext _context;
        private readonly IConfiguration _configuration;

        public AuthenticationController(FileManagementDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        //[HttpPost]
        //public async Task<ActionResult> Longin(User user)
        //{
        //    if(user!= null && user.Username != null && user.Password != null)
        //    {
        //        var userData = await GetUser(user.Username, user.Password);
        //        var jwt = _configuration.GetSection("Jwt").Get<Jwt>();
        //        if(user != null)
        //        {
        //            var claims = new[]
        //            {
        //                new Claim(JwtRegisteredClaimNames.Sub, jwt.Subject),
        //                new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
        //                new Claim(JwtRegisteredClaimNames.Iat,DateTime.UtcNow.ToString()),
        //                new Claim("Id", user.Id.ToString()),
        //                new Claim("Username", user.Username),
        //                new Claim("Password", user.Password)
        //            };
        //            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key));
        //            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        //            var token = new JwtSecurityToken(
        //                jwt.Issuer,
        //                jwt.Audience,
        //                claims,
        //                expires: DateTime.Now.AddMinutes(60),
        //                signingCredentials: signIn
        //                );

        //            return Ok(new JwtSecurityTokenHandler().WriteToken(token));
        //        }
        //        else
        //        {
        //            return BadRequest("Invalid Credentials");
        //        }
        //    }
        //    else
        //    {
        //        return BadRequest("Invalid Credentials");
        //    }

        //}
        //[HttpGet]
        //public async Task<User> GetUser(string username, string password)
        //{
        //   return await _context.Users.FirstOrDefaultAsync(u => u.Username == username && u.Password == password);

        //}

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginModel login)
        {
            var user = _context.Users.SingleOrDefault(u => u.Username == login.Username && u.Password == login.Password);

            if (user == null)
                return Unauthorized();

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes("SecrectAuthenticationKeyForGeneratingSecureJSONWebToken");
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Role, user.Role)
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);

            return Ok(new { Token = tokenString });
        }
    }


    public class LoginModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}


