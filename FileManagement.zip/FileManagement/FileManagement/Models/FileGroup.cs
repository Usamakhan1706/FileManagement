﻿namespace FileManagement.Models
{
    public class FileGroup
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
